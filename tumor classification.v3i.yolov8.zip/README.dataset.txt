# tumor classification > 2023-03-31 11:37pm
https://universe.roboflow.com/sri-venkateswara-college-of-engineering-sxdsa/tumor-classification-sbxmz

Provided by a Roboflow user
License: CC BY 4.0

